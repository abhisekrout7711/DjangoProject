from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name="home"),
    path('display_mobiles',views.display_mobiles,name="display_mobiles"),
    path('display_earphones',views.display_earphones,name="display_earphones"),
    path('add_mobile', views.add_mobile, name='add_mobile'),
    path('add_earphone', views.add_earphone, name='add_earphone'),
    path('delete_mobile/<pk>', views.delete_mobile, name='delete_mobile'),
    path('delete_earphone/<pk>', views.delete_earphone, name='delete_earphone'),
    path('edit_mobile/<pk>', views.edit_mobile, name='edit_mobile'),
    path('edit_earphone/<pk>', views.edit_earphone, name='edit_earphone'),
    path('low_inStockQty', views.low_inStockQty, name='low_inStockQty'),
    path('bill_mobile', views.bill_mobile, name='bill_mobile'),
    path('bill_earphone', views.bill_earphone, name='bill_earphone'),
    path('view_bills', views.view_bills, name='view_bills'),
    path('set_discount', views.set_discount, name='set_discount'),
    path('display_discount', views.display_discount, name='display_discount'),
]