from django.apps import AppConfig


class MobileStoreConfig(AppConfig):
    name = 'MobileStore'