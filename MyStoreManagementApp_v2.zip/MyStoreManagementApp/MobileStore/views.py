from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from django.contrib import messages
from MobileStore.models import MobilePhone, EarPhone, SaveBill, Discount
from datetime import datetime


# Create your views here.

def home(request):
    if request.user.is_authenticated:

        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block

        login_or_logout = {
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
            'header': 'You are Logged in'
        }
        login_or_logout_path: 'logout'
        login_or_logout_var: 'Log out'
        return render(request, 'home.html', login_or_logout)
    else:
        login_or_logout = {
            'login_or_logout_path': 'login',
            'login_or_logout_var': 'Log in',
            'header': 'You are not Logged in, please Log in.'
        }
        return render(request, 'home.html', login_or_logout)
    return render(request, 'home.html')
    # return HttpResponse("Hello World, this is the home page.")


def display_mobiles(request):
    if request.user.is_authenticated:

        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block

        items = MobilePhone.objects.all()
        context = {
            'items': items,
            'header': 'Mobiles',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'display.html', context)


def display_earphones(request):
    if request.user.is_authenticated:

        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block

        items = EarPhone.objects.all()
        context = {
            'items': items,
            'header': 'Earphones',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'display.html', context)


def add_item(request, cls, redirect_to_path, action_var, header):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        if request.method == 'POST':
            brand = request.POST.get('brand')
            model = request.POST.get('model')
            price = request.POST.get('price')
            inStockQty = request.POST.get('instockqty')
            FreeGift = request.POST.get('freegift')
            if brand == '' or model == '' or price == None or inStockQty == None or FreeGift == '':
                return HttpResponse('Please fill in the empty fields.')

            all_obj = cls.objects.all()
            for obj in all_obj:
                if (obj.brand.lower() == brand.lower()) and (obj.model.lower() == model.lower()):
                    # print('matched',ind_obj.brand.lower(), brand.lower(), ind_obj.model.lower(), model.lower())
                    return HttpResponse("Item already in database go and edit the existing database.")

            else:
                # print('not matched')
                # print('not matched', obj_MobilePhone.brand.lower(), brand.lower(), obj_MobilePhone.model.lower(), model.lower())
                obj = cls()
                obj.brand = brand
                obj.model = model
                obj.price = price
                obj.inStockQty = inStockQty
                obj.FreeGift = FreeGift
                obj.save()
                return redirect(redirect_to_path)
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'add.html', {'header': header, 'action_var': action_var, 'login_or_logout_path': 'logout',
                                        'login_or_logout_var': 'Log out'})


def add_mobile(request):
    return add_item(request, cls=MobilePhone, redirect_to_path='display_mobiles', action_var='/add_mobile',
                    header='Add Mobile')


def add_earphone(request):
    return add_item(request, cls=EarPhone, redirect_to_path='display_earphones', action_var='/add_earphone',
                    header='Add Earphone')


def delete_mobile(request, pk):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        MobilePhone.objects.filter(id=pk).delete()
        items = MobilePhone.objects.all()
        context = {
            'items': items,
            'header': 'Mobiles',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'display.html', context)


def delete_earphone(request, pk):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        EarPhone.objects.filter(id=pk).delete()
        items = EarPhone.objects.all()
        context = {
            'items': items,
            'header': 'Earphones',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'display.html', context)


def edit_mobile(request, pk):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        item = get_object_or_404(MobilePhone, pk=pk)
        context = {
            'brand': item.brand,
            'model': item.model,
            'price': item.price,
            'instockqty': item.inStockQty,
            'freegift': item.FreeGift,
            'header': 'Edit Mobile',
            'ID': item.pk,
            'ID_short_not': 'MP',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
        if request.method == "POST":
            item.brand = request.POST['brand']
            item.model = request.POST['model']
            item.price = request.POST['price']
            item.inStockQty = request.POST['instockqty']
            item.FreeGift = request.POST['freegift']
            item.save()
            return redirect('display_mobiles')
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'edit.html', context)


def edit_earphone(request, pk):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        item = get_object_or_404(EarPhone, pk=pk)
        context = {
            'brand': item.brand,
            'model': item.model,
            'price': item.price,
            'instockqty': item.inStockQty,
            'freegift': item.FreeGift,
            'header': 'Edit Earphone',
            'ID': item.pk,
            'ID_short_not': 'EP',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
        if request.method == "POST":
            item.brand = request.POST['brand']
            item.model = request.POST['model']
            item.price = request.POST['price']
            item.inStockQty = request.POST['instockqty']
            item.FreeGift = request.POST['freegift']
            item.save()
            return redirect('display_earphones')
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'edit.html', context)


def low_inStockQty(request):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block

        # if request.method=="POST":
        items = MobilePhone.objects.filter(inStockQty__lte=50)
        results2 = EarPhone.objects.filter(inStockQty__lte=50)
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, "low_stock.html",
                  {"items": items, 'items2': results2, 'header': 'Items running Low in Stock',
                   'login_or_logout_path': 'logout',
                   'login_or_logout_var': 'Log out', })


def create_bill(request, items, title_msg_var, action_var):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        if request.method == 'POST':
            date_var = request.POST.get('date')
            name = request.POST.get('name')
            brand = request.POST.get('brand')
            model = request.POST.get('model')

            if (name == '') or (brand == '') or (model == '') or (date_var == ''):
                # return redirect('bill_mobile/')
                print('Some None Value')
                return HttpResponse('Please fill in the empty fields.')

            elif (name != '') and (brand != '') and (model != '') and (date_var != ''):
                print('Okay all pass')
                print(name, brand, model)

                for item in items:
                    print(item.brand.lower(), item.model.lower())
                    if (item.brand.lower() == brand.lower()) and (item.model.lower() == model.lower()) and (
                            item.inStockQty >= 1):
                        # print(item.brand)
                        # print(item.model)
                        obj = SaveBill(date=date_var, name=name, brand=item.brand, model=item.model, price=item.price,
                                       FreeGift=item.FreeGift, applied_discount=0, final_price=0)
                        # print('---------------------PRICE---------------------------------------')

                        # print(obj.price)

                        discount_obj = Discount.objects.last()
                        if discount_obj != None:
                            if (obj.price >= discount_obj.min_amount):
                                obj.applied_discount = (obj.price * discount_obj.discount) / 100
                                obj.final_price = obj.price - obj.applied_discount
                        else:
                            obj.final_price = obj.price

                        item.inStockQty -= 1
                        item.save()
                        obj.save()
                        return redirect('view_bills')
                else:
                    print(item.brand.lower(), item.model.lower())
                    return HttpResponse("Sorry, The product is Out of Stock or no such product exist.")
    else:
        return HttpResponse('Not logged in, You need to login First.')

    return render(request, 'create_bill.html', {'header': title_msg_var, 'footer': '', 'action_var': action_var,
                                                'login_or_logout_path': 'logout',
                                                'login_or_logout_var': 'Log out',
                                                })


def bill_mobile(request):
    items = MobilePhone.objects.all()
    return create_bill(request, items, "Create bill for Mobile", '/bill_mobile')


def bill_earphone(request):
    items = EarPhone.objects.all()
    return create_bill(request, items, "Create bill for Earphone", '/bill_earphone')


def view_bills(request):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        items = SaveBill.objects.all()
        context = {
            'items': items,
            'header': 'All Bills',
            'login_or_logout_path': 'logout',
            'login_or_logout_var': 'Log out',
        }
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'view_bills.html', context)


def set_discount(request):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        if request.method == 'POST':
            obj = Discount()
            min_amount = request.POST.get('min_amount')
            discount = request.POST.get('discount')
            obj.min_amount = min_amount
            obj.discount = discount
            obj.save()
            return redirect(display_discount)
    else:
        return HttpResponse('Not logged in, You need to login First.')

    return render(request, 'set_discount.html', {'header': 'Set Festive Discount on all items',
                                                 'login_or_logout_path': 'logout',
                                                 'login_or_logout_var': 'Log out',
                                                 })


def display_discount(request):
    if request.user.is_authenticated:
        # I tried to replace the following if block with a function, but that doesn't work for some reasons, idk
        if request.method == 'POST':
            search_box = request.POST.get('search_box')
            objs = SaveBill.objects.filter(name=str(search_box))
            if objs:
                return search_customer(request, objs)
        # End of the above if block
        obj = Discount.objects.last()
        if obj != None:
            print(obj.min_amount, obj.discount)
            obj2 = Discount.objects.all()
            for obj3 in obj2:
                if obj3 != obj:
                    obj3.delete()

            # Discount.objects.first().delete()
            context = {
                'min_amount': obj.min_amount,
                'discount': obj.discount,
                'header': 'Applicable Discount',
                'login_or_logout_path': 'logout',
                'login_or_logout_var': 'Log out',
            }
        else:
            obj = Discount()
            obj.min_amount = 0.00
            obj.discount = 0.00
            obj.save()
            return redirect('display_discount')
            # return HttpResponse('No discount object is created yet.')
    else:
        return HttpResponse('Not logged in, You need to login First.')
    return render(request, 'display_discount.html', context)


def search_customer(request, items):
    if request.user.is_authenticated:
        pass
    else:
        return HttpResponse('Not logged in, You need to login First.')
    print('next')
    #search_box = request.POST.get('search_box')
    #items = SaveBill.objects.filter(name=str(search_box))
    for item in items:
        print(item.name, item.brand, item.model, item.date)
    context = {
        'items': items,
        'header': 'Filtered Bills',
        'login_or_logout_path': 'logout',
        'login_or_logout_var': 'Log out',
    }
    # print(context)
    return render(request, 'view_bills.html', context)


def when_to_search(request):
    if request.method == 'POST':
        print('first')
        search_box = request.POST.get('search_box')
        items = SaveBill.objects.filter(name=str(search_box))

        if items:
            return search_customer(request, items=items)

#when_to_search()
'''
    if request.method == 'POST':
        print('first')
        search_box = request.POST.get('search_box')
        objs = SaveBill.objects.filter(name=str(search_box))

        if objs:
            return search(request, objs)
'''

#new when_to_search()
'''
    if request.method == 'POST':
        print('first')
        search_box = request.POST.get('search_box')
        items = SaveBill.objects.filter(name=str(search_box))

        if items:
            return search(request, items=items)
'''
#search()
'''
def search(request):
    print('next')
    search_box = request.POST.get('search_box')
    items = SaveBill.objects.filter(name=str(search_box))
    for item in items:
        print(item.name, item.brand, item.model, item.date)
    context = {
        'items': items,
        'header': 'Filtered Bills',
        'login_or_logout_path': 'logout',
        'login_or_logout_var': 'Log out',
    }
    print(context)

    return render(request, 'view_bills.html', context)
'''