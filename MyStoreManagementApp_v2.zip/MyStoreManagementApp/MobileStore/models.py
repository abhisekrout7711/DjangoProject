from datetime import datetime, date

from django.db import models


# Create your models here.
class MobilePhone(models.Model):
    brand = models.CharField(max_length=20)
    model = models.CharField(max_length=40)
    price = models.DecimalField(max_digits=9, decimal_places=2)
    inStockQty = models.IntegerField()
    FreeGift = models.CharField(max_length=40)

    class Meta:
        verbose_name = "Mobile Phone"
        verbose_name_plural = "Mobile Phones"

    def __str__(self):
        # return self.brand
        return '{0} {1}'.format(self.brand, self.model)


class EarPhone(models.Model):
    brand = models.CharField(max_length=20)
    model = models.CharField(max_length=40)
    price = models.DecimalField(max_digits=9, decimal_places=2)
    inStockQty = models.IntegerField()
    FreeGift = models.CharField(max_length=40)

    class Meta:
        verbose_name = "Ear Phone"
        verbose_name_plural = "Ear Phones"

    def __str__(self):
        # return self.brand
        return '{0} {1}'.format(self.brand, self.model)


class SaveBill(models.Model):
    date = models.DateField()
    name = models.CharField(max_length=120)
    brand = models.CharField(max_length=20)
    model = models.CharField(max_length=40)
    price = models.DecimalField(max_digits=9, decimal_places=2)
    FreeGift = models.CharField(max_length=40)
    applied_discount= models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    final_price = models.DecimalField(max_digits=9, decimal_places=2)

    def __str__(self):
        # return self.brand
        return '{0} {1}'.format(self.name, self.brand)


class Discount(models.Model):
    min_amount=models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    discount=models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
