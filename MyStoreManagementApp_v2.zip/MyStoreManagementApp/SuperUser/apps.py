from django.apps import AppConfig


class SuperUserConfig(AppConfig):
    name = 'SuperUser'
